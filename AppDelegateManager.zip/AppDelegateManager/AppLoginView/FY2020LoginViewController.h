//
//  FY2020LoginViewController.h
//  FY_OC
//
//  Created by FangYuan on 2020/1/30.
//  Copyright © 2020 FangYuan. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FY2020LoginViewController : CFCBaseCoreViewController
+ (BaseNewNavViewController *)noLoginView;

@end

NS_ASSUME_NONNULL_END
